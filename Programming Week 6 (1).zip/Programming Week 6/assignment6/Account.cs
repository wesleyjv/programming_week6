﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment6
{
    internal class Account
    {
        private string _accountHolder;
        private double _amount;

        
        public Account(string accountHolder)
        {
            _accountHolder = accountHolder;
            _amount = 0.0;
        }

        public void Deposit(double amount)
        {
            if (amount > 0)
            {
                _amount += amount;
                LogTransaction($"Deposited: {amount}");
                Console.WriteLine("Deposit successful.");
            }
            else
            {
                Console.WriteLine("Invalid deposit amount.");
            }
        }

        
        private void LogTransaction(string message)
        {

            Console.WriteLine($"Transaction Log: {message}");
        }

        public void DisplayAccountInfo()
        {
            Console.WriteLine($"\nAccount Holder: {_accountHolder}");
            Console.WriteLine($"Current Balance: {_amount}\n");
        }
    }
}
