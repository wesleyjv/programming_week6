﻿using assignement7;

namespace week6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {


            Console.Write("Enter name of product: ");
            string name = Console.ReadLine();

            Console.Write("Enter price of product: "); 
            double price = double.Parse(Console.ReadLine());


            Product product = new Product(name, price);

            product.DisplayProductInfo();


        }
    }
}
