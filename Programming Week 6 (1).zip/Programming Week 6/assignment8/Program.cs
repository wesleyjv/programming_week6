﻿using System;

namespace assignment8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {

            Console.Write("Enter account number: ");
            string accountNumber = Console.ReadLine();

            Console.Write("Enter initial balance: ");
            double initialBalance;
            while (!double.TryParse(Console.ReadLine(), out initialBalance) || initialBalance < 0)
            {
                Console.Write("Invalid input. Please enter a valid initial balance: ");
            }

            BankAccount account = new BankAccount(accountNumber, initialBalance);

            // Deposit funds
            Console.Write("Enter amount to deposit: ");
            double depositAmount;
            while (!double.TryParse(Console.ReadLine(), out depositAmount) || depositAmount <= 0)
            {
                Console.Write("Invalid input. Please enter a valid positive amount: ");
            }
            account.Deposit(depositAmount);

            // Withdraw funds
            Console.Write("Enter amount to withdraw: ");
            double withdrawAmount;
            while (!double.TryParse(Console.ReadLine(), out withdrawAmount) || withdrawAmount <= 0)
            {
                Console.Write("Invalid input. Please enter a valid positive amount: ");
            }
            account.Withdraw(withdrawAmount);

            // Display account information
            Console.WriteLine($"Account Number: {account.AccountNumber}");
            Console.WriteLine($"Current Balance: {account.Balance}");
        }
    }
}
