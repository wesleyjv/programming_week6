﻿namespace assignment5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {
            // Declare and initialize an integer
            int number = 10;

            // Display the original value
            Console.WriteLine($"Original value: {number}");

            ModifyByValue(number);
            Console.WriteLine($"Value after ModifyByValue: {number}");

            ModifyByReference(ref number);
            Console.WriteLine($"Value after ModifyByReference: {number}");
        }

        // Method to demonstrate passing by value
        static void ModifyByValue(int value)
        {
            value = 20;  // Change the local copy of the variable
        }

        // Method to demonstrate passing by reference
        static void ModifyByReference(ref int value)
        {
            value = 20;  // Change the actual value of the variable
        }
    }
}
