﻿namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }

        void Start()
        {
            
            Console.Write("Enter a car make: ");
            string make = Console.ReadLine();

            Console.Write("Enter a car model: ");
            string model = Console.ReadLine();

            Console.Write("Enter the car year: ");
            int year = int.Parse(Console.ReadLine());

            // Create a new Car object
            Car car = new Car(make, model, year);

            // Display the car details
            Console.WriteLine("\nCar details:");
            Console.WriteLine($"Make: {car.Make}");
            Console.WriteLine($"Model: {car.Model}");
            Console.WriteLine($"Year: {car.Year}");
        }
    }
}
