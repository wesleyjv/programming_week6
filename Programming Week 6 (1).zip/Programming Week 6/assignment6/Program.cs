﻿namespace assignment6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();

        }

        void Start()
        {

            Console.Write("Enter account holder name: ");
            string accountHolder = Console.ReadLine();

            Account account = new Account(accountHolder);

            // Ask the user for a deposit amount
            Console.Write("Enter deposit amount: ");
            double depositAmount;
            while (!double.TryParse(Console.ReadLine(), out depositAmount))
            {
                Console.WriteLine("Invalid input. Please enter a valid deposit amount:");
            }

            // Deposit the amount
            account.Deposit(depositAmount);

            // Display account information
            account.DisplayAccountInfo();
        }
    }
}
