﻿namespace assignement4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();

        }

        void Start()
        {
            Console.Write("Enter a radius: ");
            double radius = double.Parse(Console.ReadLine());

            Circle circle = new Circle(radius);
            circle.DisplayInfo();
        }
    }
}
