﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignement7
{
    internal class Product
    {

        public string Name { get; private set; }
        public double Price { get; }

        public Product(string name, double price)
        {
            Name = name;
            Price = price;
        }


        public void DisplayProductInfo()
        {
            Console.WriteLine($"Product name: {Name}");
            Console.WriteLine($"Product price: {Price}");
        }
    }
}
